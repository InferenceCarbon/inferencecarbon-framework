#!/usr/bin/env python3
"""Campaign driver: loops `inferencecarbon_bench.py run` with the exact
task-specified parameters until ALL_DONE or stopped_on_budget.
Safety: max 70 fires; abort if `pending` fails to fall across 3 consecutive fires.
Writes final status to results/_driver_<provider>_final.json
"""
import json, re, subprocess, sys, time, os

prov = sys.argv[1]
cap = sys.argv[2]
os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))  # owned_benchmark
cmd = ["python3", "inferencecarbon_bench.py", "run", "--provider", prov,
       "--workload", "10k", "--repeats", "1", "--max-output", "2500",
       "--budget", cap, "--time-budget", "3", "--request-timeout", "40"]

log = open(f"results/_driver_{prov}.log", "a")
pending_hist, measured, final, stall = [], 0, None, False
for fire in range(1, 71):
    p = subprocess.run(cmd, capture_output=True, text=True)
    out = p.stdout
    log.write(f"\n===== fire {fire} rc={p.returncode} =====\n" + out + (p.stderr or ""))
    log.flush()
    idx = out.rfind("{\n")
    if idx < 0:
        log.write("NO_JSON_IN_OUTPUT — stopping\n")
        stall = True
        break
    try:
        js = json.loads(out[idx:])
    except Exception as e:
        log.write(f"JSON_PARSE_FAIL {e} — stopping\n")
        stall = True
        break
    final = js
    measured += js.get("models_this_call", 0)
    if js.get("ALL_DONE") or js.get("stopped_on_budget"):
        break
    pending_hist.append(js.get("pending"))
    if len(pending_hist) >= 3 and pending_hist[-1] == pending_hist[-2] == pending_hist[-3]:
        stall = True
        log.write("STALL: pending unchanged across 3 consecutive fires — stopping\n")
        break

result = {"provider": prov, "fires": fire, "measured_this_session": measured,
          "stall": stall, "final": final}
with open(f"results/_driver_{prov}_final.json", "w") as f:
    json.dump(result, f, indent=1)
log.close()
